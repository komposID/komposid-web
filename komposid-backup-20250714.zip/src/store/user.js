export const userSession = {
  nama: "Yhonif",
  role: "Admin",
  foto: "https://i.pravatar.cc/100" // bisa diganti nanti
}
